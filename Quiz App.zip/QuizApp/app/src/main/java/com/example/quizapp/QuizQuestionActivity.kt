package com.example.quizapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class QuizQuestionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_question)
    }
}